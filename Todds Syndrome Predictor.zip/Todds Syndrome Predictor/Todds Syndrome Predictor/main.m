//
//  main.m
//  Todds Syndrome Predictor
//
//  Created by Jacob Israel on 11/17/16.
//  Copyright © 2016 Jacob Israel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
