//
//  ToddsSyndromeLookupView.m
//  Todds Syndrome Predictor
//
//  Created by Jacob Israel on 11/17/16.
//  Copyright © 2016 Jacob Israel. All rights reserved.
//
#import "ToddsSyndromeLogic.h"
#import "ToddsSyndromeLookupView.h"
#import "SmartButton.h"

@implementation ToddsSyndromeLookupView
{
@private
    UILabel* titleLabel;
    SmartButton* backButton;
    SmartButton* lookupButton;
    UILabel* resultsLabel;
    UITextField* patientNameField;
    UIView* alertView;
}

/*! ===========================
 @function   initWithFrame:
 @discussion
 @param the frame
 @return self
 ============================= */
-(instancetype) initWithFrame:(CGRect)frame{
    self = [super initWithFrame: frame];
    if(self){
        CGFloat minimumDimension = MIN(frame.size.width, frame.size.height);
        UIFont* basicFont = [UIFont fontWithName:@"Helvetica" size:18 + minimumDimension/80];
        
        self.backgroundColor = [UIColor whiteColor];
        titleLabel = [[UILabel alloc]init];
        titleLabel.text = @"Lookup probability for a patient";
        titleLabel.font = basicFont;
        titleLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview: titleLabel];
        
        backButton = [[SmartButton alloc]initWithSelector: @selector(dismissView) forObject: self withTitle: @"Back" andTooltip: nil];
        [self addSubview: backButton];
        
        lookupButton = [[SmartButton alloc]initWithSelector: @selector(lookupPatientResults) forObject:self  withTitle: @"Look up" andTooltip: @"Find the saved value for a patient"];
        [self addSubview: lookupButton];
        
        patientNameField = [[UITextField alloc]init];
        patientNameField.backgroundColor = [UIColor lightTextColor];
        patientNameField.placeholder = @"Patient Name";
        patientNameField.textAlignment = NSTextAlignmentRight;
        patientNameField.font = basicFont;
        [self addSubview: patientNameField];
        
        resultsLabel = [[UILabel alloc]init];
        resultsLabel.font = basicFont;
        resultsLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview: resultsLabel];

        [self setupViewsWithFrame: frame];
    }
    return self;
}

/*! ===========================
 @function    setupViewsWithFrame:
 @discussion
 Redo the views on start and rotation
 ============================= */
-(void) setupViewsWithFrame:(CGRect) newFrame{
    
    [super setupViewsWithFrame: newFrame];
    CGFloat myWidth = self.frame.size.width;
    CGFloat myHeight = self.frame.size.height;
    CGFloat minimumDimension = MIN(myHeight, myWidth);
    CGRect frame = CGRectMake( 0, 0, myWidth, myHeight*0.1);
    [titleLabel setFrame: frame];
    
    CGFloat xOffset = myWidth * 0.05;
    CGFloat yOffset = myHeight * 0.1;
    CGFloat labelWidth = minimumDimension * 0.5;
    CGFloat labelHeight = labelWidth * 0.15;

    CGFloat buttonWidth = minimumDimension * 0.25;
    CGFloat buttonHeight = buttonWidth * 0.25;
    
    frame = CGRectMake(xOffset, yOffset, buttonWidth, buttonHeight);
    [backButton setFrame: frame];
    
    frame = CGRectMake(myWidth - xOffset - buttonWidth,  yOffset, buttonWidth, buttonHeight);
    [lookupButton setFrame: frame];
    
    frame = CGRectMake( myWidth - labelWidth - xOffset, yOffset + buttonHeight*1.25, labelWidth, buttonHeight);
    [patientNameField setFrame: frame];
    
    frame = CGRectMake(0, (myHeight - labelHeight)/2, myWidth, labelHeight);
    [resultsLabel setFrame: frame];
}

/*! ===========================
 @function  lookupPatientResults
 @discussion
 ============================= */
-(void) lookupPatientResults{
 
    [patientNameField resignFirstResponder];
    NSString* patientName = patientNameField.text;
    
    if(patientName.length == 0){
        [self showAlert: @"Please enter a Patient Name"];
    }
    else{
        CGFloat result = [ToddsSyndromeLogic getProbabilityOfToddsSyndromeForPatient: patientName];
        if(result >=0){
            [resultsLabel setText:[NSString stringWithFormat:@"Result: %0.1f %%", result*100]];
        }
        else{
            [resultsLabel setText: @""];
            [self showAlert: @"Sorry. No results were found for this patient"];
        }
    }
}

@end
