//
//  ViewController.h
//  Todds Syndrome Predictor
//
//  Created by Jacob Israel on 11/17/16.
//  Copyright © 2016 Jacob Israel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ToddsSyndromeQueryView.h"
#import "ToddsSyndromeLookupView.h"

@interface ViewController : UIViewController <SmartViewDelegate>


@end

