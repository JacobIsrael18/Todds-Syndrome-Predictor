//
//  ToddsSyndromeLogic.m
//  Todds Syndrome Predictor
//
//  Created by Jacob Israel on 11/17/16.
//  Copyright © 2016 Jacob Israel. All rights reserved.
//

#import "ToddsSyndromeLogic.h"


@implementation ToddsSyndromeLogic

/*! ===========================
 @function  getFactorList
 @discussion
 ============================= */
+ (NSDictionary<NSNumber*,  NSString*>*) getFactorList{
    static NSDictionary<NSNumber*,  NSString*>* factorList = nil;
    // If multi-threaded, we will need a     dispatch_once_t
    if (factorList == nil) {
        NSMutableDictionary<NSNumber*, NSString*>* tempList = [[NSMutableDictionary alloc]init];

        [tempList setObject: @"has migraines" forKey: [NSNumber numberWithInt: HAS_MIGRAINES]];
        [tempList setObject: @"is 15 or younger" forKey: [NSNumber numberWithInt: IS_15_OR_YOUNGER]];
        [tempList setObject: @"is male" forKey: [NSNumber numberWithInt: IS_A_MALE]];
        [tempList setObject: @"has used hallucinogenic drugs" forKey: [NSNumber numberWithInt: HAS_USED_HALLUCINOGENIC_DRUGS]];
        
        factorList = tempList;
    }
    return factorList;
}

/*! ===========================
 @function storeProbabilityOfToddsSyndrome:  forPatient:
 @discussion
 ============================= */
+ (void) storeProbabilityOfToddsSyndrome:(CGFloat) probability forPatient:(NSString*) patientName
{
    NSUserDefaults* standardDefaults = [NSUserDefaults standardUserDefaults];
    NSString* toddsSyndromeKey = [[NSString stringWithFormat:@"ProbabilityOfToddsSyndrome%@", patientName] lowercaseString];
    [standardDefaults setObject: [NSNumber numberWithFloat: probability] forKey: toddsSyndromeKey];
}

/*! ===========================
@function getProbabilityOfToddsSyndrome:  forPatient:
 @discussion
 ============================= */
+ (CGFloat) getProbabilityOfToddsSyndromeForPatient:(NSString*) patientName
{
    NSUserDefaults* standardDefaults = [NSUserDefaults standardUserDefaults];
    NSString* toddsSyndromeKey = [[NSString stringWithFormat:@"ProbabilityOfToddsSyndrome%@", patientName]lowercaseString];
    NSNumber* probability = [standardDefaults objectForKey: toddsSyndromeKey];
    if(probability == nil){
        return -1;
    }
    return [probability floatValue];
}

/*! ===========================
 @function   getProbabilityOfToddsSyndromeForPatientWithFactors:
 
 @discussion
 Returns -1 if there is a usage error
 Should throw an error in the future.
 ============================= */
+ (CGFloat) getProbabilityOfToddsSyndromeForPatientWithFactors:  (NSDictionary<NSNumber*,  NSNumber*>*) factors{
    
    if(factors.count != TOTAL_FACTORS){
        NSLog(@"FAILURE in getProbabilityOfToddsSyndromeForPatientWithFactors: %lu != %u", (unsigned long)factors.count , TOTAL_FACTORS);
        return -1;
    }
    
    CGFloat  probability  = 0;
    for(NSNumber* boolAsNumber in [factors allValues]){
        if( [boolAsNumber boolValue]){
            probability ++ ;
        }
    }
    probability /= TOTAL_FACTORS;
    
    return  probability;
}

@end
