//
//  ViewController.m
//  Todds Syndrome Predictor
//
//  Created by Jacob Israel on 11/17/16.
//  Copyright © 2016 Jacob Israel. All rights reserved.
//

#import "ViewController.h"
#import "SmartButton.h"


@interface ViewController ()
@end

@implementation ViewController
{
@private
//    UIView* yesNoContainerView;
    ToddsSyndromeQueryView* queryView;
    ToddsSyndromeLookupView* lookupView;
    UILabel* mainTitleLabel;
 
    UIColor* lightBlue, *lightViolet, *lightOrage;
    
    SmartButton* performQueryButton;
    SmartButton* lookupResultsButton;
    enum{PERFORM_QUERY, LOOKUP_RESULTS};
}

/*! ===========================
 @function  viewDidLoad
 @discussion
 ============================= */
- (void)viewDidLoad {
    [super viewDidLoad];
    queryView = nil;
    lookupView = nil;
    
    if(mainTitleLabel == nil){
        
        CGFloat minimumDimension = MIN(self.view.frame.size.width, self.view.frame.size.height);
        
        UIFont* simpleFont = [UIFont fontWithName: @"Arial" size:18 + minimumDimension/80];
        mainTitleLabel = [[UILabel alloc]init];
        mainTitleLabel.textAlignment = NSTextAlignmentCenter;
        mainTitleLabel.text = @"Todds Syndrome Predictor";
        mainTitleLabel.font = simpleFont;
 
        lookupResultsButton  = [[SmartButton alloc]initWithSelector: @selector( showView:)  forObject: self withTitle: @"Lookup Results"  andTooltip:@"Find the previous results for a patient"];
        lookupResultsButton.tag = LOOKUP_RESULTS;

        performQueryButton = [[SmartButton alloc]initWithSelector: @selector(showView:) forObject: self withTitle: @"Perform Query" andTooltip: @"Calculate the chance that a patient has Todd's Syndrome"];
        performQueryButton.tag = PERFORM_QUERY;
        
        [self.view addSubview: mainTitleLabel];
        [self.view addSubview: performQueryButton];
        [self.view addSubview:  lookupResultsButton];
        
        lightBlue = [UIColor colorWithRed: 0.9 green: 0.9 blue: 1 alpha:1];
        lightViolet = [UIColor colorWithRed: 1 green: 0.9 blue: 1 alpha:1];
        lightOrage = [UIColor colorWithRed: 1 green:1  blue: 0.8  alpha:1];
                self.view.backgroundColor = lightOrage;
    }
    [self setupViews];
}

#pragma  mark - Private methods
/*! ===========================
 @function setupViews
 @discussion
 ============================= */
-(void)setupViews{
    
    CGFloat myWidth = self.view.frame.size.width;
    CGFloat myHeight= self.view.frame.size.height;
    
    CGRect frame = CGRectMake(0,0,myWidth,myHeight*0.2);
    [mainTitleLabel setFrame: frame];
    
    CGFloat minimumDimension = MIN(myWidth, myHeight);
    CGFloat buttonWidth = minimumDimension * 0.35;
    CGFloat buttonHeight = buttonWidth * 0.22;
    CGFloat buttonOffestX = myWidth  * 0.05;
    CGFloat buttonOffestY = myHeight  * 0.15;
    CGFloat buttonGap = buttonHeight * 0.33;
    
    frame = CGRectMake(buttonOffestX, buttonOffestY, buttonWidth, buttonHeight);
    [performQueryButton setFrame: frame];
    
    frame = CGRectMake(buttonOffestX, buttonOffestY + buttonHeight + buttonGap, buttonWidth, buttonHeight);
    [lookupResultsButton setFrame: frame];
    
    // If it's nil, it won't matter
    [lookupView setupViewsWithFrame: self.view.frame];
    [queryView setupViewsWithFrame: self.view.frame];
}


/*! ===========================
 @function  showView:
 @discussion
 ============================= */
- (void) showView: (UIButton*) theButton{
    switch (theButton.tag) {
        case PERFORM_QUERY:
            queryView = [[ToddsSyndromeQueryView alloc]initWithFrame: self.view.frame];
            queryView.smartViewDelegate = self;
            queryView.tag = PERFORM_QUERY;
            queryView.backgroundColor = lightViolet;
            [self.view addSubview: queryView];
            break;
        case LOOKUP_RESULTS:
            lookupView = [[ToddsSyndromeLookupView alloc]initWithFrame: self.view.frame];
            lookupView.smartViewDelegate = self;
            lookupView.tag = LOOKUP_RESULTS;
            lookupView.backgroundColor = lightBlue;
            [self.view addSubview: lookupView];
            break;
    }
}

/*! ===========================
 @function  hideView:
 @discussion
 ============================= */
- (void) hideView: (UIButton*) theButton{
    switch (theButton.tag) {
        case PERFORM_QUERY:
            [queryView removeFromSuperview];
            queryView = nil;
            break;
        case LOOKUP_RESULTS:
            [lookupView removeFromSuperview];
            queryView = nil;
            break;
    }
}

#pragma  mark - SmartViewDelegate
/*! ===========================
 @function  smartViewWasDismissed:
 @discussion
 ============================= */
-(void) smartViewWasDismissed:(SmartView*) theView{
    UIButton* fakeButton = [[UIButton alloc]init];
    fakeButton.tag = theView.tag;
    [self hideView: fakeButton];
}


#pragma  mark -
/*! ===========================
 @function  viewWillTransitionToSize: withTransitionCoordinator:
 @discussion
 ============================= */
-(void) viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator{
    
    dispatch_time_t waitTimeSeconds = coordinator.transitionDuration* 1.1;
    dispatch_after(waitTimeSeconds, dispatch_get_main_queue(), ^(){
        [self setupViews];
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
