/********************************************
 SmartView.m
 Todds Syndrome Predictor
 
 Created by Jacob Israel on 11/18/16.
 Copyright © 2016 Jacob Israel. All rights reserved.
 ********************************************/
#import "SmartView.h"
#import "SmartButton.h"

@implementation SmartView
{
@private
    CGFloat currentX;
    CGFloat targetX;
    NSTimeInterval animationDelay;
    UIView* alertView;
}

/*! ===========================
 @function initWithFrame:
 @discussion
 Contructor
 @param
 The target frame
 ============================= */
-(instancetype) initWithFrame:(CGRect)frame{
    targetX = frame.origin.x;
    currentX = - frame.size.width;
    animationDelay = 0.05; /// 50 milliseconds
    CGRect newFrame = CGRectMake(currentX, frame.origin.y, frame.size.width, frame.size.height);
    self = [super initWithFrame:  newFrame];
    if (self) {
        [self performSelector: @selector(animateFrame) withObject: self afterDelay: animationDelay];
    }
    return  self;
}

/*! ===========================
 @function    animateFrame
 @discussion
 No need for a ViewController
 This view animates itself.
 ============================= */
-(void) animateFrame{
    CGFloat deltaX = (targetX - currentX);
    CGFloat newX = currentX + deltaX * 0.5;
    CGRect newFrame = CGRectMake(newX, self.frame.origin.y, self.frame.size.width, self.frame.size.height);
    [self setFrame: newFrame];
    
    currentX = newX;
    
    if (fabs(deltaX) > 1) {
        [self performSelector: @selector(animateFrame)  withObject: self afterDelay: animationDelay];
    }
    else if(targetX < 0 && [_smartViewDelegate respondsToSelector: @selector(smartViewWasDismissed:)] ){
        [_smartViewDelegate smartViewWasDismissed: self];
    }
}

/*! ===========================
 @function   dismissView
 @discussion
 Start the animation out
 ============================= */
-(void) dismissView{
    targetX = - self.frame.size.width;
    [self performSelector: @selector(animateFrame)  withObject: self afterDelay: animationDelay];
}

/*! ===========================
 @function   showAlert:
 @discussion
 Place a modal alert over this view
 ============================= */
-(void) showAlert:(NSString*) alertText{
    
    CGFloat minimumDimension = MIN(self.frame.size.width, self.frame.size.height);
    
    alertView = [[UIView alloc]initWithFrame: self.frame];
    
    CGFloat labelWidth = minimumDimension*0.6;
    CGFloat labelHeight = minimumDimension*0.25;
    
    CGRect frame = CGRectMake((self.frame.size.width - labelWidth) / 2, self.frame.size.height/2 - labelHeight,
                              labelWidth, labelHeight);
    
    UILabel* label = [[UILabel alloc]initWithFrame: frame];
    label.backgroundColor = [UIColor whiteColor];
    label.font = [UIFont fontWithName: @"Arial" size: 18 + minimumDimension/220];
    label.text = alertText;
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    label.layer.cornerRadius = minimumDimension/60;
    label.layer.borderColor = [[UIColor blackColor]CGColor];
    label.layer.borderWidth = 1.0;
    
    [alertView addSubview: label];
    alertView.backgroundColor = [UIColor lightTextColor];
    
    CGFloat buttonWidth = minimumDimension*0.12;
    CGFloat buttonHeight = buttonWidth * 0.35;
    
    frame = CGRectMake((self.frame.size.width - buttonWidth)/2, self.frame.size.height/2 - buttonHeight*1.5, buttonWidth, buttonHeight);
    
    SmartButton* okButton = [[SmartButton alloc]initWithFrame: frame selector: @selector(hideAlert:)  forObject:self  withTitle:@"OK" andTooltip:nil];
    okButton.tag = OK_BUTTON;
    [alertView  addSubview: okButton];
    
    [self addSubview: alertView];
}

/*! ===========================
 @function   askYesOrNo:
 @discussion
 Ask the user a Yes/No question
 ============================= */
-(void) askYesOrNo:(NSString*) alertText{
    
    CGFloat minimumDimension = MIN(self.frame.size.width, self.frame.size.height);
    alertView = [[UIView alloc]initWithFrame: self.frame];
    CGFloat labelWidth = minimumDimension*0.7;
    CGFloat labelHeight = minimumDimension*0.25;
    CGFloat labelY = minimumDimension/4;
    
    CGRect frame = CGRectMake((self.frame.size.width - labelWidth)/2, labelY,
                              labelWidth, labelHeight);
    
    UILabel* label = [[UILabel alloc]initWithFrame: frame];
    label.backgroundColor = [UIColor whiteColor];
    label.font = [UIFont fontWithName: @"Arial" size: 18 + minimumDimension/220];
    label.text = alertText;
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    label.layer.cornerRadius = minimumDimension/60;
    label.layer.borderColor = [[UIColor blackColor]CGColor];
    label.layer.borderWidth = 1.0;
    
    [alertView addSubview: label];
    alertView.backgroundColor = [UIColor lightTextColor];
    
    CGFloat buttonWidth = minimumDimension * 0.12;
    CGFloat buttonHeight = buttonWidth * 0.35;
    CGFloat buttonGap = buttonHeight/2.0;
    
    for(int i = 0 ; i < 2 ; i++){
        frame = CGRectMake((self.frame.size.width - buttonWidth)/2 + (buttonWidth/2 + buttonGap) * (2*i - 1),
                           labelY + labelHeight - buttonHeight*1.25, buttonWidth, buttonHeight);
        SmartButton* button = [[SmartButton alloc]initWithFrame: frame selector: @selector(hideAlert:)  forObject:self  withTitle:@"Yes" andTooltip: nil];
        if(i == 0){
            button.tag = YES_BUTTON;
        }
        else{
            button.tag = NO_BUTTON;
            [button setTitle: @"No"  forState: UIControlStateNormal];
        }
        [alertView  addSubview: button];
    }
    [self addSubview: alertView];
}

/*! ===========================
 @function   hideAlert:
 @discussion
 ============================= */
-(void) hideAlert:(SmartButton*) theButton{
    [alertView removeFromSuperview];
    alertView = nil;
    [self userAnsweredYesNoWith: theButton.tag];
}

/*! ===========================
 @function    userAnsweredYesNoWith:
 @discussion
 OVERRIDE THIS METHOD
 The child class should override this method to retrieve the answer.
 ============================= */
-(void) userAnsweredYesNoWith:(uint8_t) answer{
    NSLog(@"You were supposed to override this method:    userAnsweredYesNoWith:");
    switch (answer) {
        case YES_BUTTON:
            break;
        case NO_BUTTON:
            break;
        case OK_BUTTON:
            break;
    }
}

@end
