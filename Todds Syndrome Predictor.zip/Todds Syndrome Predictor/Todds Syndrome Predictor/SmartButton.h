//
//  SmartButton.h
//  TestApp
//
//  Created by Jacob Israel on 12/11/14.
//  Copyright © 2014 Citrix Systems. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol SmartButtonDelegate

@end

@interface SmartButton : UIButton
@property(nonatomic, strong) NSString* toolTipText;

- (id)initWithSelector:(SEL) buttonPressSelector forObject:(NSObject*) buttonPressTarget withTitle:(NSString*)title andTooltip:(NSString *)text;
- (id)initWithFrame:(CGRect)frame selector:(SEL) buttonPressSelector forObject:(NSObject*) buttonPressTarget
        withTitle:(NSString*)title andTooltip:(NSString *)text;

@end
