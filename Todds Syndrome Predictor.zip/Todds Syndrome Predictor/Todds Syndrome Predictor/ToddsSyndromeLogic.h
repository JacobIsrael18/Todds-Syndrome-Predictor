/********************************************
  ToddsSyndromeLogic.h
  Todds Syndrome Predictor

  Created by Jacob Israel on 11/17/16.
  Copyright © 2016 Jacob Israel. All rights reserved.
********************************************/
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

enum ToddsSyndromeFactor{
    HAS_MIGRAINES,  IS_15_OR_YOUNGER, IS_A_MALE, HAS_USED_HALLUCINOGENIC_DRUGS,
    
    // *** Keep this last ***
    TOTAL_FACTORS
};

@interface ToddsSyndromeLogic : NSObject
+ (NSDictionary<NSNumber*,  NSString*>*) getFactorList;
+ (void) storeProbabilityOfToddsSyndrome:(CGFloat) probability forPatient:(NSString*) patientName;
+ (CGFloat) getProbabilityOfToddsSyndromeForPatient:(NSString*) patientName;
+ (CGFloat) getProbabilityOfToddsSyndromeForPatientWithFactors:  (NSDictionary<NSNumber*,  NSNumber*>*) factors;
@end

