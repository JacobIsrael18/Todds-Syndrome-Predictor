//******************************************************************
//  SmartButton.m
//
//  Created by Jacob Israel on 10/4/14.
//  Copyright © 2014 Citrix Systems. All rights reserved.
//
//******************************************************************
#import <Foundation/Foundation.h>
#import "SmartButton.h"
#import <mach/mach_time.h>


@interface SmartButton()
{
@private
    double touchTimeSeconds;
    double toolTipShowTimeSeconds;
    SEL mySelector;
    BOOL fingerIsDown;
    UILabel* toolTip;
}
@property(nonatomic) UIViewController* toolTipViewController;


@end

@implementation SmartButton

/*! ===========================
 @function    initWithFrame:  selector:  buttonTitle: andTooltip:
 @discussion
 @param frame
 @param  buttonPressSelector - the method to call when the button is pressed
 @param  buttonPressTarget - owner of the selector
 @param  title - the button's text
 @param  text - the ToolTip text that will show when you hold your finger on the button
 @return self
 @return self
 ============================= */
- (id)initWithFrame:(CGRect)frame selector:(SEL) buttonPressSelector forObject:(NSObject*) buttonPressTarget
          withTitle:(NSString*)title andTooltip:(NSString *)text{
    self = [super initWithFrame: frame];
    if (self){
        touchTimeSeconds = [SmartButton getTimeInSeconds];
        toolTipShowTimeSeconds = 0.6;
        [self setTitle: title forState: UIControlStateNormal];
        _toolTipText = text;
        toolTip = nil;
        fingerIsDown = NO;
        [self setTitleColor: [UIColor blackColor] forState:UIControlStateNormal];
        self.titleLabel.adjustsFontSizeToFitWidth = YES;
        CGFloat minimumDimension = MIN(frame.size.width, frame.size.height);
        self.titleLabel.font = [UIFont fontWithName:@"Helvetica" size:18+minimumDimension/8];
        self.layer.borderColor = [[UIColor blackColor]CGColor];
        self.layer.borderWidth = 1.0;
        self.layer.cornerRadius = minimumDimension/4;
        self.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1];
        
        //    self.titleLabel.adjustsFontSizeToFitWidth =  YES;
        
        if([buttonPressTarget respondsToSelector: buttonPressSelector]){ //                           Do NOT use TouchDown
            [self addTarget: buttonPressTarget action: buttonPressSelector forControlEvents:UIControlEventTouchUpInside];
        }
    }
    return self;
}

/*! ===========================
 @function       initWithSelector:  buttonTitle: andTooltip:
 @discussion
 @param  buttonPressSelector - the method to call when the button is pressed
 @param  buttonPressTarget - owner of the selector
 @param  title - the button's text
 @param  text - the ToolTip text that will show when you hold your finger on the button
 @return self
 ============================= */
- (id)initWithSelector:(SEL) buttonPressSelector forObject:(NSObject*) buttonPressTarget withTitle:(NSString*)title andTooltip:(NSString *)text{
    CGRect frame = CGRectMake(0, 0, 54, 18);
    
    self = [[SmartButton alloc]initWithFrame: frame selector: buttonPressSelector forObject: buttonPressTarget withTitle: title andTooltip: text];
    
    return self;
}

/*! ===========================
 @function        touchesEnded: withEvent:
 @discussion
 @param
 ============================= */
-(void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    //
    //    self pressesEnded:  withEvent:
    double  deltaTime = [SmartButton getTimeInSeconds] - touchTimeSeconds;
    
    if(deltaTime < toolTipShowTimeSeconds){
        [super touchesEnded: touches withEvent: event];
    }
    fingerIsDown = NO;
    [toolTip removeFromSuperview];
    toolTip = nil;
}

/*! ===========================
 @function        touchesBegan: withEvent:
 @discussion
 Intercept the touches and decide of it is a long press.
 @param touches
 @param event
 ============================= */
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesBegan: touches  withEvent: event];
    fingerIsDown = YES;
    touchTimeSeconds =  [SmartButton getTimeInSeconds];
    [self performSelector: @selector(showToolTip) withObject: self afterDelay: toolTipShowTimeSeconds];
}

/*! ===========================
 @function   showToolTip
 @discussion
 Show the tooltip if its text is not empty and 
 the user did not lift her finger yet.
 ============================= */
-(void) showToolTip{
    if( fingerIsDown == NO || _toolTipText.length < 1){
        return;
    }
    CGFloat width = self.frame.size.width;
    CGFloat height = self.frame.size.height;
    CGFloat toolTipWidth = width*1.5;
    CGFloat toolTipHeight = height*2;
    
    CGFloat toolTipX = width*0.95;
    if(self.frame.origin.x > toolTipWidth){
        toolTipX = - toolTipWidth*0.95;
    }
    CGFloat toolTipY = (height - toolTipHeight)/2;
 
    CGRect toolTipRect = CGRectMake(toolTipX, toolTipY, toolTipWidth, toolTipHeight);
    toolTip = [[UILabel alloc]initWithFrame: toolTipRect];
    toolTip.font = [UIFont fontWithName:@"Arial" size:18+height/26];
    toolTip.layer.borderColor = [UIColor blackColor].CGColor;
    toolTip.layer.borderWidth = 1.0f;
    toolTip.layer.cornerRadius = toolTipWidth/18;
    toolTip.layer.masksToBounds = YES;
    toolTip.textColor = [UIColor blackColor];
    toolTip.text = _toolTipText;
    toolTip.textAlignment = NSTextAlignmentCenter;
    toolTip.numberOfLines = 0;
    [toolTip setBackgroundColor: [UIColor colorWithRed:1 green:1 blue:0.5 alpha: 0.75]];
    [self addSubview: toolTip];
    
}

/*! ====================================
 @function    getTimeInSeconds
 @discussion
 ====================================*/
+(double) getTimeInSeconds{
    
    static  mach_timebase_info_data_t timebaseInfo;
    static double multiplier = 0.04;
    static dispatch_once_t oneTimeMutex = 0;
    dispatch_once(&oneTimeMutex, ^{
        mach_timebase_info(&timebaseInfo);
        if(timebaseInfo.denom > 0){
            multiplier = (double)timebaseInfo.numer / (timebaseInfo.denom*1000000000.0); // NanoSeconds -> Seconds
        }
    });
    
    double timeSeconds = mach_absolute_time() * multiplier;
    return  timeSeconds;
}
@end
