//
//  AppDelegate.h
//  Todds Syndrome Predictor
//
//  Created by Jacob Israel on 11/17/16.
//  Copyright © 2016 Jacob Israel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

