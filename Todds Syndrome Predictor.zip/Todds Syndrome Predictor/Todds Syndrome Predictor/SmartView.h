/********************************************
 SmartView.h
 Todds Syndrome Predictor
 
 Created by Jacob Israel on 11/18/16.
 Copyright © 2016 Jacob Israel. All rights reserved.
 ********************************************/

#import <UIKit/UIKit.h>

@class SmartView; // Forward declaration

@protocol SmartViewDelegate
-(void) smartViewWasDismissed:(SmartView*) theView;
@end

@interface SmartView : UIView
enum{OK_BUTTON, YES_BUTTON, NO_BUTTON};

-(void) showAlert:(NSString*) alertText;
-(void) askYesOrNo:(NSString*) alertText;
-(void) userAnsweredYesNoWith:(uint8_t) answer; // child classes should override this method
-(void) setupViewsWithFrame:(CGRect) newFrame;
-(void) dismissView;
@property(nonatomic, weak) NSObject <SmartViewDelegate>* smartViewDelegate;
@end
