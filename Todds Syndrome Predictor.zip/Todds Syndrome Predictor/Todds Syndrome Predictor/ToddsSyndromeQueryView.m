//
//  ToddsSyndromeQueryView.m
//  Todds Syndrome Predictor
//
//  Created by Jacob Israel on 11/17/16.
//  Copyright © 2016 Jacob Israel. All rights reserved.
//

#import "ToddsSyndromeQueryView.h"
#import "ToddsSyndromeLogic.h"
#import "SmartButton.h"

@implementation ToddsSyndromeQueryView
{
@private

    UILabel* titleLabel;
    NSArray<UILabel*>* factorLabelArray;
    NSArray<UISwitch*>* factorSwitchArray;
    
    SmartButton* backButton;
    SmartButton* savePredictionResultsButton;
    UILabel* predictionResultsLabel;
    UIView* alertView;
    CGFloat latestResult;
    UITextField* patientNameField;
}

/*! ===========================
 @function   initWithFrame:
 @discussion
 @param the frame
 @return self
 ============================= */
-(instancetype) initWithFrame:(CGRect)frame{
    self = [super initWithFrame: frame];
    if(self){
        CGFloat minimumDimension = MIN(frame.size.width, frame.size.height);
        
        UIFont* largeFont = [UIFont fontWithName:@"Helvetica" size:18 + minimumDimension/80];
        UIFont* mediumFont = [UIFont fontWithName:@"Helvetica" size:18 + minimumDimension/120];
        
        self.backgroundColor = [UIColor whiteColor];
        titleLabel = [[UILabel alloc]init];
        titleLabel.text = @"Todd's Syndrome Probability";
        titleLabel.font = largeFont;
        titleLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview: titleLabel];
        
        patientNameField = [[UITextField alloc]init];
        patientNameField.backgroundColor = [UIColor lightTextColor];
        patientNameField.textAlignment = NSTextAlignmentRight;
        patientNameField.placeholder = @"Patient Name";
        patientNameField.font = largeFont;
        [self addSubview: patientNameField];
        
        predictionResultsLabel = [[UILabel alloc]init];
        predictionResultsLabel.textAlignment = NSTextAlignmentCenter;
        predictionResultsLabel.numberOfLines = 0;
        predictionResultsLabel.font = largeFont;
        predictionResultsLabel.textColor = [UIColor blackColor];
        [self addSubview: predictionResultsLabel];
        
        backButton = [[SmartButton alloc]initWithSelector: @selector(dismissView)  forObject:self  withTitle:@"Back" andTooltip: nil];
        [self addSubview: backButton];
        
        savePredictionResultsButton = [[SmartButton alloc]initWithSelector: @selector(saveResults) forObject:self  withTitle: @"Save Results" andTooltip: @"Put the results for a patient into memory"];
        [self addSubview: savePredictionResultsButton];
                
        NSDictionary* factorList = [ToddsSyndromeLogic getFactorList];
        
        NSMutableArray* tempArray = [[NSMutableArray alloc]init];
        
        UILabel* newLabel;
        for(int i = 0 ; i < TOTAL_FACTORS ; i++){
            newLabel = [[UILabel alloc]init];
            newLabel.text = [factorList objectForKey: [NSNumber numberWithInt: i]];
            //            newLabel.adjustsFontSizeToFitWidth = YES;
            newLabel.font = mediumFont;
            newLabel.numberOfLines = 0;
            newLabel.tag = i;
            [self addSubview: newLabel];
            [tempArray addObject: newLabel];
        }
        factorLabelArray = tempArray;
        
        tempArray = [[NSMutableArray alloc]init];
        UISwitch* newSwitch;
        for(int i = 0 ; i < TOTAL_FACTORS ; i++){
            newSwitch = [[UISwitch alloc]init];
            [newSwitch addTarget: self action:@selector(showResults) forControlEvents:UIControlEventValueChanged];
            [newSwitch setOn: NO];
            newSwitch.tag = i;
            [self addSubview: newSwitch];
            [tempArray addObject: newSwitch];
        }
        factorSwitchArray = tempArray;
        
        [self setupViewsWithFrame: frame];
        [self showResults];
    }
    return self;
}

/*! ===========================
 @function   showResults
 @discussion
 ============================= */
-(void) showResults{
    NSMutableDictionary<NSNumber*,  NSNumber*>* switchSettings = [[NSMutableDictionary alloc]init];
    NSNumber* boolNumber;
    UISwitch* theSwitch;
    
    for(int i = 0 ; i < TOTAL_FACTORS ; i++){
        theSwitch = factorSwitchArray[i];
        boolNumber = [NSNumber numberWithBool: theSwitch.isOn];
        
        [switchSettings setObject: boolNumber forKey:[NSNumber numberWithInt: i]];
    }
    latestResult = [ToddsSyndromeLogic getProbabilityOfToddsSyndromeForPatientWithFactors:  switchSettings];
    [predictionResultsLabel setText: [NSString stringWithFormat:@"Result %0.1f %%", latestResult*100]];
}

/*! ===========================
 @function   saveResults
 @discussion
 ============================= */
-(void) saveResults{
    
    [patientNameField resignFirstResponder];
    NSString* patientName = patientNameField.text;
    
    if(patientName.length == 0){
        
        [self showAlert: @"Please enter a Patient Name"];
    }
    else if([ToddsSyndromeLogic getProbabilityOfToddsSyndromeForPatient: patientName] >= 0){
        [self askYesOrNo: @"There is already a stored result for this patient. Would you like to overwrite it ?"];
    }
    else{ // New Patient
        [ToddsSyndromeLogic storeProbabilityOfToddsSyndrome: latestResult forPatient: patientName];
        [self showAlert: [NSString stringWithFormat: @"Results saved for patient: %@", patientName]];
    }
}

/*! ===========================
 @overriden
 @function    userAnsweredYesNoWith:
 @discussion
 ============================= */
-(void) userAnsweredYesNoWith:(uint8_t) answer{
    switch (answer) {
        case YES_BUTTON:
            [self overwriteResults];
            break;
        case NO_BUTTON:
        case OK_BUTTON:
            // do nothing
            break;
    }
}

/*! ===========================
 @function   overwriteResults
 @discussion
 ============================= */
-(void) overwriteResults{
    NSString* patientName = patientNameField.text;
    [ToddsSyndromeLogic storeProbabilityOfToddsSyndrome: latestResult forPatient: patientName];
    [self showAlert: [NSString stringWithFormat: @"New results saved for patient."]];
}

/*! ===========================
 @function    setupViewsWithFrame:
 @discussion
 Redo the views on start and rotation
 ============================= */
-(void) setupViewsWithFrame:(CGRect) newFrame{
    
    [self setFrame: newFrame];
    CGFloat myWidth = self.frame.size.width;
    CGFloat myHeight = self.frame.size.height;
    CGFloat minimumDimension = MIN(myWidth, myHeight);
    CGRect frame = CGRectMake( 0, 0, myWidth, myHeight*0.1);
    [titleLabel setFrame: frame];
    
    CGFloat xOffset = myWidth * 0.05;
    CGFloat buttonOffsetY = myHeight * 0.08;
    CGFloat yOffset = myHeight * 0.18;
    CGFloat labelHeight = minimumDimension* 0.12;
    CGFloat labelWidth = minimumDimension * 0.55;
    CGFloat labelGapY= labelHeight * 0.05;
    CGFloat switchOffsetX = xOffset + labelWidth * 1.2;
    UILabel* theLabel;
    UISwitch* theSwitch;
    
    CGFloat buttonWidth = minimumDimension * 0.25;
    CGFloat buttonHeight = buttonWidth * 0.25;
    
    frame = CGRectMake(xOffset, buttonOffsetY, buttonWidth, buttonHeight);
    [backButton setFrame: frame];
    
    frame = CGRectMake(myWidth - labelWidth*1.1,buttonOffsetY+buttonHeight*1.1, labelWidth, buttonHeight);
    [patientNameField setFrame: frame];
    
    frame = CGRectMake(myWidth - buttonWidth*1.1,buttonOffsetY, buttonWidth, buttonHeight);
    [savePredictionResultsButton setFrame: frame];
    
    frame = CGRectMake(0, (labelHeight+labelGapY)*(TOTAL_FACTORS +3), myWidth, labelHeight);
    [predictionResultsLabel setFrame: frame];
    
    for(int i = 0 ; i < TOTAL_FACTORS ; i++){
        theSwitch = factorSwitchArray[i];
        theLabel = factorLabelArray[i];
        frame = CGRectMake( xOffset, yOffset +i*(labelHeight+labelGapY) , labelWidth, labelHeight);
        [theLabel setFrame:frame];
        frame = CGRectMake(switchOffsetX, yOffset +i*(labelHeight+labelGapY) , labelWidth, labelHeight);
        [theSwitch setFrame:frame];
    }
}
@end
