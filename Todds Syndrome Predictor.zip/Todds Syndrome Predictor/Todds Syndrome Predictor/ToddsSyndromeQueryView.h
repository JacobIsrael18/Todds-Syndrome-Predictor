//
//  ToddsSyndromeQueryView.h
//  Todds Syndrome Predictor
//
//  Created by Jacob Israel on 11/17/16.
//  Copyright © 2016 Jacob Israel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SmartView.h"

@interface ToddsSyndromeQueryView : SmartView
-(void) setupViewsWithFrame:(CGRect) newFrame;
@end
