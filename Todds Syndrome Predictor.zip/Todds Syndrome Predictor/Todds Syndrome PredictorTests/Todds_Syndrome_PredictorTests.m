//
//  Todds_Syndrome_PredictorTests.m
//  Todds Syndrome PredictorTests
//
//  Created by Jacob Israel on 11/17/16.
//  Copyright © 2016 Jacob Israel. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "ToddsSyndromeLogic.h"
@interface Todds_Syndrome_PredictorTests : XCTestCase

@end

@implementation Todds_Syndrome_PredictorTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}


- (void)testStorageAndRecoveryTest {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    NSString* patientName;
    
    for(CGFloat i = 0 ; i < 1.0 ; i += 0.01){
        patientName = [NSString stringWithFormat:@"Patient Name %u", (uint32_t)(i*1000)];
        [ToddsSyndromeLogic storeProbabilityOfToddsSyndrome: i forPatient: patientName];
    }
    CGFloat recoveredProbability, answerDifference;
    
    for(CGFloat i = 0 ; i < 1.0 ; i += 0.01){
        patientName = [NSString stringWithFormat:@"Patient Name %u", (uint32_t)(i*1000)];
        recoveredProbability = [ToddsSyndromeLogic getProbabilityOfToddsSyndromeForPatient: patientName];
        answerDifference = recoveredProbability - i;
        NSLog(@"%f", answerDifference);
        if (fabs(answerDifference) > 0.0001) {
            XCTFail( @"storageAndRecoveryTest FAILURE %f != %f", recoveredProbability, i);
        }
    }
    /*    XCTAssertNotNil( )     XCTAssert( )     */
}


- (void)testProbabilityCalculation {
 
    NSMutableDictionary<NSNumber*,  NSNumber*>* dictionary = [[NSMutableDictionary alloc]init];
    BOOL randomFactor;
    CGFloat totalProbability = 0;
    
    for(int i = 0 ; i < TOTAL_FACTORS ; i++){
        if(rand() % 2 == 0){
            randomFactor = YES;
            totalProbability++ ;
        }
        else{
            randomFactor = NO;
            
        }
        [dictionary setObject:[NSNumber numberWithBool: randomFactor] forKey:[NSNumber numberWithInt: i] ];
    }
    
    totalProbability /= TOTAL_FACTORS;
    
    CGFloat discoveredProbability = [ToddsSyndromeLogic  getProbabilityOfToddsSyndromeForPatientWithFactors:  dictionary];
    
    if(totalProbability != discoveredProbability){
        XCTFail( @"testProbabilityCalculation FAILURE %f != %f", totalProbability, discoveredProbability);
    }
}




- (void)testPerformanceTime{
   
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
